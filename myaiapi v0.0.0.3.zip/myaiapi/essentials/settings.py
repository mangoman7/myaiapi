class Settings():
    def __init__(self,**kwargs):
        self.settings = kwargs